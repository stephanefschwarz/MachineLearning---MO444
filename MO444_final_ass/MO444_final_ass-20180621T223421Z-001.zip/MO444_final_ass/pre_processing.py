#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import pandas as pd
import numpy as np
from googletrans import Translator
from utils import Patterns


def url_to_tag(document):

	return re.sub(Patterns.URL, u'<URL>', document)

def at_to_tag(document):

	return re.sub(Patterns.AT, u'<AT>', document)

def hash_to_tag(document):

	return re.sub(Patterns.HASH, u'<HASH>', document)	

def number_to_tag(document):

	return re.sub(Patterns.NUM, u'<NUM>', document)

def emoji_to_tag(document):

	document = document.decode('utf-8')

	return re.sub(Patterns.EMOJIS, u'<EMO>', document)

def smileys_to_tag(document):

	return re.sub(Patterns.EMOJIS, u'<SMI>', document)

def translate_document(document):

	translator = Translator()
	
	translated_document = []

	return translator.translate(document, dest='en')

def pre_processing_text(post):

	print(post)
	post = emoji_to_tag(post)
	post = url_to_tag(post)
	post = at_to_tag(post)
	post = hash_to_tag(post)
	post = number_to_tag(post)
	post = smileys_to_tag(post)
	return translate_document(post)

if __name__ == '__main__':
	
	dataframe = pd.read_table("tweets.txt")

	posts = dataframe["tweetText"]

	label = dataframe["label"]
	i = 0
	for post in posts:

		print(i)
		i+=1

		processed_post = pre_processing_text(post)
		posts.replace(post, processed_post)

	fakenews_dataframe = pd.concat([posts, label], axis=1)

	posts.to_csv("new_fakenews_dataframe")

