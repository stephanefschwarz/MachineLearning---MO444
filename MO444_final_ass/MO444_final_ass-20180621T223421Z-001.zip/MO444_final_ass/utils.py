import re
import emoji

class Patterns:

	URL = re.compile('((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)')

	AT = re.compile('@[a-zA-Z]+')

	HASH = re.compile('#[a-zA-Z]+')

	NUM = re.compile('[0-9]+')

	SMILEYS_PATTERN = re.compile(r'(?:X|:|;|=)(?:-)?(?:\)|\(|O|D|P|S){1,}', re.IGNORECASE)

	#l = []
	#for e in emoji.UNICODE_EMOJI.keys():

		#l.append(e)

	#EMOJIS = re.compile('|'.join(e))

	try:

		EMOJIS = re.compile(u'([\U00002600-\U000027BF])|([\U0001f300-\U0001f64F])|([\U0001f680-\U0001f6FF])')
	
	except re.error:

		EMOJIS = re.compile(u'([\u2600-\u27BF])|([\uD83C][\uDF00-\uDFFF])|([\uD83D][\uDC00-\uDE4F])|([\uD83D][\uDE80-\uDEFF])')
